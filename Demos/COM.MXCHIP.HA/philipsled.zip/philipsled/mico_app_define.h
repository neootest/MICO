#ifndef __MICO_APP_DEFINE_H
#define __MICO_APP_DEFINE_H

#include "mico_define.h"

#define APP_INFO   "mxchipWNet HA Demo based on MICO OS"

#define FIRMWARE_REVISION   "MICO_HA_2_9"
#define HARDWARE_REVISION   "3162"
#define DEFAULT_NAME        "Wi-Fi Led"
#define MODEL               "Philips Wi-Fi LED"
#define MANUFACTURER        "MXCHIP Inc."
#define PROTOCOL            "com.mxchip.ha"
#define LOCAL_PORT          8080

/*User provided configurations*/
#define CONFIGURATION_VERSION 0x0000029 // if changed default configuration, add this num
#define MAX_Local_Controller_Client  4

/**/
typedef struct
{
  uint32_t          configDataVer;
  uint32_t          localServerPort;

  /*local services*/
  bool              localServerEnable;

  /*IO settings*/
  uint32_t          USART_BaudRate;
} application_config_t;

/*Running status*/
typedef struct _current_app_status_t {
  int*              localControllerClient_fd;
  int               localControllerListener_fd;
  mico_thread_t     localController_thread_handler;
} current_app_status_t;

#endif

