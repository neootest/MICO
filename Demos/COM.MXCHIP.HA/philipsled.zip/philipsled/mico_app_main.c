#include "platform.h"
#include "mxchipWNET.h"
#include "mico_define.h"
#include "Common.h"
#include "Debug.h"
#include "mico_rtos.h"
#include "StringUtils.h"
#include "mico_callback.h"
#include "mico_app_define.h"
#include "SocketUtils.h"

#define app_log(M, ...) custom_log("APP", M, ##__VA_ARGS__)
#define app_log_trace() custom_log_trace("APP")


static mico_timer_t _report_timer;
static void localController_thread(void *inContext);

static void Send_Report(int fd){
  char value = (char)(TIM_GetCapture3(TIM4)/50);
  SocketSend( fd, (uint8_t *)&value, 1 );
}

void appRestoreDefault_callback(mico_Context_t *inContext)
{
  inContext->flashContentInRam.appConfig.localServerPort = LOCAL_PORT;
  inContext->flashContentInRam.appConfig.USART_BaudRate = DEFAULT_USART_BaudRate;
}

static void report_timer_handler(void* arg ){
  int i;
  mico_Context_t * context = arg;
  for(i = 0; i < MAX_Local_Controller_Client; i++) {
    if (context->appStatus.localControllerClient_fd[i] != -1) {
      Send_Report(context->appStatus.localControllerClient_fd[i]);
    }
  }
}

static void _proccessIncomingMessage(void *buf, size_t len){
  (void)len;
  TIM_SetCompare3(TIM4, (*(char *)buf)*50);
}

void PWM_Init(void);

OSStatus startMicoApplication( mico_Context_t * const inContext )
{
  app_log_trace();

  OSStatus err = kUnknownErr;
  require_action(inContext, exit, err = kParamErr);

  err = mico_rtos_create_thread(&inContext->appStatus.localController_thread_handler, MICO_APPLICATION_PRIORITY, "Local Server", localController_thread, 0x500, (void*)inContext );
  require_noerr_action( err, exit, app_log("ERROR: Unable to start the EasyLink thread.") );

exit:
  return err;

}

void localController_thread(void *inContext)
{
  app_log_trace();
  OSStatus err = kUnknownErr;
  int i, j,con, len;
  mico_Context_t *Context = inContext;
  struct sockaddr_t addr;
  fd_set readfds;
  struct timeval_t t;
  char *buf, ip_address[16];
  
  buf = (char*)malloc(3*1024);
  require_action(buf, exit, err = kNoMemoryErr);
  PWM_Init();
  mico_init_timer(&_report_timer, 2000, report_timer_handler, inContext);
  mico_start_timer(&_report_timer);

  Context->appStatus.localControllerListener_fd = -1;
  Context->appStatus.localControllerClient_fd = (int *)malloc(sizeof(int) * MAX_Local_Controller_Client);
  for(i=0;i<MAX_Local_Controller_Client;i++) 
    Context->appStatus.localControllerClient_fd[i] = -1;
  
  t.tv_sec = 10;
  t.tv_usec = 0;
  
  /*Establish a TCP server that accept the tcp clients connections*/
  if (Context->appStatus.localControllerListener_fd == -1) {
    Context->appStatus.localControllerListener_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    require_action(IsValidSocket( Context->appStatus.localControllerListener_fd ), exit, err = kNoResourcesErr);

    addr.s_ip = INADDR_ANY;
    addr.s_port = Context->flashContentInRam.appConfig.localServerPort;
    err = bind(Context->appStatus.localControllerListener_fd, &addr, sizeof(addr));
    require_noerr( err, exit );

    err = listen(Context->appStatus.localControllerListener_fd, 0);
    require_noerr( err, exit );

    app_log("Server established at port: %d, fd: %d\r\n", Context->flashContentInRam.appConfig.localServerPort,\
                                                                       Context->localControllerListener_fd);
  }

  
  while(1){
    /*Check status on erery sockets */
    FD_ZERO(&readfds);
    FD_SET(Context->appStatus.localControllerListener_fd, &readfds);  
    for(i = 0; i < MAX_Local_Controller_Client; i++) {
      if (Context->appStatus.localControllerClient_fd[i] != -1)
        FD_SET(Context->appStatus.localControllerClient_fd[i], &readfds);
    }
    
    select(1, &readfds, NULL, NULL, &t);
    
    /*Check tcp connection requests */
    if(FD_ISSET(Context->appStatus.localControllerListener_fd, &readfds)){
      j = accept(Context->appStatus.localControllerListener_fd, &addr, &len);
      if (j > 0) {
        inet_ntoa(ip_address, addr.s_ip );
        app_log("Client %s:%d connected, fd: %d\r\n", ip_address, addr.s_port, j);
        for(i = 0; i < MAX_Local_Controller_Client; i++) {
          if (Context->appStatus.localControllerClient_fd[i] == -1) {
            Context->appStatus.localControllerClient_fd[i] = j;
            Send_Report(j);
            break;
          }
        }
      }
    }
    
    /*Read data from tcp clients and send data back */ 
    for(i = 0; i < MAX_Local_Controller_Client; i++) {
      if (Context->appStatus.localControllerClient_fd[i] != -1) {
        if (FD_ISSET(Context->appStatus.localControllerClient_fd[i], &readfds)) {
          con = recv(Context->appStatus.localControllerClient_fd[i], buf, 1, 0);
          if (con > 0) {
            _proccessIncomingMessage(buf, con);
            //send(inContext->localControllerClient_fd[i], buf, con, 0);
          }
          else {
            close(Context->appStatus.localControllerClient_fd[i]);
            app_log("Client closed, fd: %d\r\n", Context->localControllerClient_fd[i]);
            Context->appStatus.localControllerClient_fd[i] = -1;
          }
        }
      }
    }
  }

exit:
    app_log("Exit: Local controller exit with err = %d", err);
    free(buf);
    mico_rtos_delete_thread(NULL);
    return;
}

void PWM_Init(void)
{  
  GPIO_InitTypeDef GPIO_InitStructure;
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  TIM_OCInitTypeDef  TIM_OCInitStructure;
  
  uint16_t  PrescalerValue;
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
 
   //…Ë÷√∏√“˝Ω≈Œ™ ‰≥ˆπ¶ƒ‹, ‰≥ˆTIM9 CH1µƒPWM¬ˆ≥Â≤®–Œ GPIOE.5
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; //TIM_CH2
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  //
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
  GPIO_Init(GPIOB, &GPIO_InitStructure);//≥ı ºªØGPIO
  
  /* Connect TIM9 pins to AF3 */  
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_TIM4);
 
   /* Compute the prescaler value 10MHz*/
  PrescalerValue = (uint16_t) ((SystemCoreClock /2) / 10000000) - 1;
 
   //≥ı ºªØTIM9
  TIM_TimeBaseStructure.TIM_Period = 5000; //period: 10000000/2000 - 1=2000  (TIM3 counter clock / TIM3 output clock) - 1 (2000Hz)
  TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue; 
  TIM_TimeBaseStructure.TIM_ClockDivision = 0; 
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure); 
  //≥ı ºªØTIM9 Channel1 PWMƒ£ Ω  
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //—°‘Ò∂® ±∆˜ƒ£ Ω:TIM¬ˆ≥ÂøÌ∂»µ˜÷∆ƒ£ Ω2
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //±»Ωœ ‰≥ˆ πƒ‹
  TIM_OCInitStructure.TIM_Pulse = 1000;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; // ‰≥ˆº´–‘:TIM ‰≥ˆ±»Ωœº´–‘∏ﬂ
  
  TIM_OC3Init(TIM4, &TIM_OCInitStructure);  //∏˘æ›T÷∏∂®µƒ≤Œ ˝≥ı ºªØÕ‚…ËTIM9 OC1
  
  TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Disable);  // πƒ‹TIM3‘⁄CCR2…œµƒ‘§◊∞‘ÿºƒ¥Ê∆˜
  
  TIM_ARRPreloadConfig(TIM4, ENABLE);
 
  TIM_Cmd(TIM4, ENABLE);  // πƒ‹TIM9
  
}


